package com.ec.v1;


import java.util.ArrayList;
import java.util.List;

import com.ec.config.Config;
import com.ec.config.ConfigContext;
import com.ec.v1.customer.Customer;
import com.ec.v1.customer.dto.GetDTO;

public class CustomerSdkDemo {
	public static void main(String[] args) throws Exception {
		CustomerSdkDemo demo = new CustomerSdkDemo();
		 demo.getCustomFieldMapping();
		 demo.get();
	}
	
	/**
	 * 
	 * @Title: getCustomFieldMapping
	 * @Description: 客户相关接口:   获取自定义字段
	 * @throws Exception
	 * @author shicy
	 * @date 2020-03-10 04:44:00
	 */
	public void getCustomFieldMapping() throws Exception {
		// 自己提供实现, 这里是 EC 开发人员自己实现的配置，只适合他们调用，你的配置可能不同
		Config config = ConfigMrg.getConfig();
		
		//首次调用接口 必须要调用这个方法初始化配置
		ConfigContext.initConfig(config);
		// 调用公共包
		int type =1 ;
		String result = Customer.getCustomFieldMapping(type);
		// TODO
		System.out.println(result);   
	}
	
	/**
	 * 
	 * @Title: get
	 * @Description: 客户 - 批量精确查询客户 测试
	 * @throws Exception
	 * @author shicy
	 * @date 2020-03-10 05:25:05
	 */
	public void get() throws Exception {
		// 自己提供实现, 这里是 EC 开发人员自己实现的配置，只适合他们调用，你的配置可能不同
		Config config = ConfigMrg.getConfig();
		
		//首次调用接口 必须要调用这个方法初始化配置
		ConfigContext.initConfig(config);
		// 调用公共包
		List<GetDTO> list = new ArrayList<GetDTO>();
		GetDTO dot1 = new GetDTO();
		dot1.setCrmId(3021689514L);
		dot1.setMobile("15745678910");
		list.add(dot1);
	
		GetDTO dot2 = new GetDTO();
		dot2.setCrmId(3021689513L);
		dot2.setMobile("15945678910");
		
		list.add(dot2);
		
		
		
		String result = Customer.get(list);
	
		// TODO 处理业务
		System.out.println(result);   
		
	}
}
