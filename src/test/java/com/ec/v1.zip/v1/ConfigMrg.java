package com.ec.v1;

import com.alibaba.fastjson.JSONObject;

import com.ec.config.Config;
import com.ec.config.ConfigContext;
import com.ec.utils.EcUtils;

public class ConfigMrg {
    private static Config config = null;
    private static final Byte lock = 0;

    /**
     * @Title: getConfig
     * @Description: 获取一个配置
     * <p>
     * 这里是 test 的代码， 实际上，token 根据您的应用来实现getConfig， 不能直接用于您的代码， 您这样的提供一个配置， 或者稍作修改
     * </p>
     * @author shicy
     * @date 2020-03-10 01:58:58
     */
    public static Config getConfig() throws Exception {
        if (config == null) {
            synchronized (lock) {
                if (config == null) {
                    config = new Config();
                    config.setCorpId("xx");
                    config.setAppId("xx");
                    config.setSecret("xx");
                    // token 会定期变动的，您可以查询 token 接口之后，定期返回
                    // EC 内部测试， 您一般不需要指定
                    config.setDomain("https://open.workec.com");
                    // 更新 token , 实际上， 你不需要每次都去更新， 你需要换成你的 token ， 过期了，在去查询
                    updateToken();
                }
            }
        }
        return config;
    }


    public static void updateToken() throws Exception {
        // 首次调用接口 必须要调用这个方法初始化配置
        ConfigContext.initConfig(config);
        String result = EcUtils.getToken();
        JSONObject json = JSONObject.parseObject(result);
        String accessToken = json.getJSONObject("data").getString("accessToken");
        config.setToken(accessToken);
        ConfigContext.setToken(accessToken);
        System.out.println("更新token 成功，accessToken =  " + accessToken);
    }

    public static void main(String[] args) {
        System.out.println("fdfdf");
    }
}
