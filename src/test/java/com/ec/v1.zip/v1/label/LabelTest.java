package com.ec.v1.label;

import com.ec.config.Config;
import com.ec.config.ConfigContext;
import com.ec.v1.ConfigMrg;
import com.ec.v1.label.dto.LabelDTO;
import com.ec.v1.label.vo.LabelInfoVO;

import java.util.ArrayList;
import java.util.List;

public class LabelTest {

    public static void main(String[] args) throws Exception {
        testGetLabelInfo();
    }

    public static void testAddLabelGroup() throws Exception {
        Config config = ConfigMrg.getConfig();
        //首次调用接口 必须要调用这个方法初始化配置
        ConfigContext.initConfig(config);
        LabelDTO result = Label.addLabelGroup("测试3", null, null, 5003582L);
        System.out.println(result);
    }

    public static void testAddLabel() throws Exception {
        Config config = ConfigMrg.getConfig();
        //首次调用接口 必须要调用这个方法初始化配置
        ConfigContext.initConfig(config);
        LabelDTO result = Label.addLabel("openApi222", "测试3", 5003582L);
        System.out.println(result);
    }
    public static void testUpdate() throws Exception {
        Config config = ConfigMrg.getConfig();
        //首次调用接口 必须要调用这个方法初始化配置
        ConfigContext.initConfig(config);
        LabelInfoVO labelInfoVO = new LabelInfoVO();
        labelInfoVO.setCrmId(161026049L);
        labelInfoVO.setUserId(5003582L);
        labelInfoVO.setLabels("ggg");
        labelInfoVO.setType(2);
        List<LabelInfoVO> list = new ArrayList<>();
        list.add(labelInfoVO);
        LabelDTO result = Label.update(list);
        System.out.println(result);
    }
    public static void testGetLabelInfo() throws Exception {
        Config config = ConfigMrg.getConfig();
        //首次调用接口 必须要调用这个方法初始化配置
        ConfigContext.initConfig(config);

        LabelDTO result = Label.getLabelInfo("测试3");
        System.out.println(result);
    }
}
