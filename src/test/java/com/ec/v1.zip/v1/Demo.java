package com.ec.v1;

public class Demo {
	public static void main(String[] args) {
		byte[] bytes = "~".getBytes();
		System.out.println(bytes.length);
	}
}
