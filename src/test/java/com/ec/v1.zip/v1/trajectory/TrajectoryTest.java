package com.ec.v1.trajectory;

import com.ec.config.Config;
import com.ec.config.ConfigContext;
import com.ec.v1.ConfigMrg;
import com.ec.v1.trajectory.vo.TrajectoryVo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class TrajectoryTest {

    public static void main(String[] args) throws Exception {
        Config config = ConfigMrg.getConfig();
        //首次调用接口 必须要调用这个方法初始化配置
        ConfigContext.initConfig(config);
        testfindHistoryUserTrajectory();
    }

    private static void testSaveUserTrajectory() throws IOException {
        List<TrajectoryVo> list = new ArrayList<>();
        TrajectoryVo trajectoryVo = new TrajectoryVo();
        trajectoryVo.setContent("apitest444");
        trajectoryVo.setId("12314774");
        trajectoryVo.setUserId("5003582");
        trajectoryVo.setCrmId(161026049L);
        list.add(trajectoryVo);
        System.out.println(Trajectory.saveUserTrajectory(list));
    }

    // todo 测试未通过
    private static void testfindUserTrajectory() throws IOException {
        System.out.println(Trajectory.findUserTrajectory(null, "5003582", "161026049", "2020-02-25", "2020-03-12", null));
    }

    //todo 测试未通过
    private static void testfindHistoryUserTrajectory() throws IOException {
        System.out.println(Trajectory.findHistoryUserTrajectory(null, "5003582", "161026049", 2020, 3, 1, 12, null));
    }
}
