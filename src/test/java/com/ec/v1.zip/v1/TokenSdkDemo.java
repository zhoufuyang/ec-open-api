package com.ec.v1;



import com.alibaba.fastjson.JSONObject;
import com.ec.utils.EcUtils;
import com.ec.config.Config;
import com.ec.config.ConfigContext;

/**
 * 
 * @Title: TokenSdkTest.java
 * @Description: token sdk 接入 例子
 * @author shicy
 * @date 2020-03-10 02:19:52
 */
public class TokenSdkDemo{
	
	public static void main(String[] args) throws Exception {
		TokenSdkDemo demo = new TokenSdkDemo();
		demo.getToken();
	}
	
	/**
	 * 
	 * @Title: testGetToken
	 * @Description: 测试  获取 token 接口
	 * @throws Exception
	 * @author shicy
	 * @date 2020-03-10 02:25:49
	 */
	public void getToken() throws Exception {
		// 自己提供实现, 这里是 EC 开发人员自己实现的配置，只适合他们调用，你的配置可能不同
		Config config = ConfigMrg.getConfig();
		
		//首次调用接口 必须要调用这个方法初始化配置
		ConfigContext.initConfig(config);
		String result = EcUtils.getToken();
		//config.setToken(result);
		// 处理业务...
		JSONObject json = JSONObject.parseObject(result);
		String accessToken = json.getJSONObject("data").getString("accessToken");
		ConfigContext.setToken(accessToken);
		System.out.println(result);   
	}
}
